using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.TestTools.CodeCoverage.Editor.Tests")]
