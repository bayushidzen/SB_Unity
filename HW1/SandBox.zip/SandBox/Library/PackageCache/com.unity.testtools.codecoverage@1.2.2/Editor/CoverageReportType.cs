namespace UnityEditor.TestTools.CodeCoverage
{
    internal enum CoverageReportType
    {
        Full,
        FullEmpty,
        CoveredMethodsOnly
    }
}
